/* UDAAN directory settings. This is the only file you need to edit to go live.
   Both settings are optional: with neither, the directory works read-only and the
   Ask panel answers with built-in search. */
window.UDAAN_CONFIG = {
  /* Firebase web app config (Firebase console > Project settings > General > Your apps > Web app).
     Turns on sign-in, shared progress logging and "Add commitment". Leave as null to skip. */
  firebase: null,
  /* Example:
  firebase: {
    apiKey: "AIza...",
    authDomain: "udaan-directory.firebaseapp.com",
    projectId: "udaan-directory",
    appId: "1:1234567890:web:abc123"
  },
  */

  /* Optional and paid (Anthropic API usage). URL of your deployed chat worker, see README step 3.
     Leave "" to use the free built-in answer engine. */
  chatProxyUrl: "",

  /* Live, read-only link to the UDAAN Cohort Calendar (Project Tracking System).
     The directory reads the calendar's cohorts and compares what has actually been
     trained with what was committed to the EU. It never writes to the calendar.
     Set to null to switch the link off. */
  cohortCalendar: {
    firebase: {
      apiKey: "AIzaSyAMNX-2uYxPj91hF226buvoSRT4U_NiDo4",
      authDomain: "ai-native-cohort-calendar.firebaseapp.com",
      projectId: "ai-native-cohort-calendar",
      appId: "1:391119496671:web:449d82144bca36a4c7106a"
    },
    /* Each calendar program, its Firestore collection, and the directory commitment it feeds.
       defaultYears mirrors the calendar's MASTER_TARGETS, used if Settings has no targets saved. */
    programs: [
      { key: "ai_native",     label: "AI Native",     collection: "udaan_events",               commitment: "ai-native",     defaultYears: { 2026: 2000, 2027: 7000, 2028: 7000, 2029: 4000 } },
      { key: "ai_foundation", label: "AI Foundation", collection: "udaan_events_ai_foundation", commitment: "ai-foundation", defaultYears: { 2026: 375, 2027: 375, 2028: 375, 2029: 375 } },
      { key: "ai_deep",       label: "AI Deep",       collection: "udaan_events_ai_deep",       commitment: "ai-deep",       defaultYears: { 2026: 125, 2027: 125, 2028: 125, 2029: 125 } }
    ],
    configDoc: "udaan_config/project_tracking",
    url: "https://gitparihub-naamii.github.io/AI-Native-Cohort-Depo/",

    /* Keeps this link in step with the calendar's code on GitHub: when you switch the toggle on,
       the directory reads the calendar's index.html (cached 12 hours) and picks up its current
       Firebase project, programs, collections and master targets. The settings above are the fallback. */
    autoDetectFrom: "https://raw.githubusercontent.com/gitparihub-NAAMII/AI-Native-Cohort-Depo/main/index.html",

    /* Whether "Connect with Project Tracking System" starts on for someone's first visit.
       After that, each person's own choice is remembered in their browser. */
    defaultOn: false
  }
};
