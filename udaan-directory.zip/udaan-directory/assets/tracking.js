/* Live link to the UDAAN Cohort Calendar (Project Tracking System).
   Counting rules mirror the calendar's own buildUnits()/unitPeopleTrained(), so the
   numbers here match its Master Dashboard:
   - institution cohort: participants count once the cohort is "completed"
   - open cohort: seats taken by individuals count once the cohort is "completed"
   - individual with no open cohort on that date: 1 person once "completed", unless waitlisted */

const n = v => { const x = parseInt(v, 10); return isNaN(x) || x < 0 ? 0 : x; };
const PIPELINE = ["confirmed", "reserved", "booked"];
const GENDER = ["men", "women", "otherGender", "pns"];
const MARGINALIZED = ["janajati", "madhesi", "tharu", "dalit", "muslim"];

const isIndividual = e => !!e && e.applicantType === "individual";
const isOpen = e => !!e && e.applicantType !== "individual" && n(e.capacity) > 0;
const seatsTaken = (date, evs) => evs.filter(e => isIndividual(e) && e.status !== "cancelled" && !e.waitlisted && (e.cohortDate || e.date) === date).length;

/** Turns one program's raw event documents into countable units. */
function units(evs) {
  const out = [];
  for (const e of evs) {
    if (isIndividual(e) && evs.some(c => isOpen(c) && c.date === e.date)) continue; // counted via its open cohort
    const done = e.status === "completed";
    const trained = isOpen(e) ? (done ? seatsTaken(e.date, evs) : 0)
      : isIndividual(e) ? (done && !e.waitlisted ? 1 : 0)
      : (done ? n(e.participants) : 0);
    const planned = isOpen(e) ? (n(e.capacity) || seatsTaken(e.date, evs)) : isIndividual(e) ? 1 : n(e.participants);
    const u = { status: e.status || "", date: e.date || "", year: parseInt(String(e.date || "").slice(0, 4), 10) || null,
      trained, planned, done, province: e.province || "", sector: e.sector || "",
      changedAt: e.lastActionAt || e.updatedAt || e.createdAt || "" };
    ["men", "women", "otherGender", "pns", "a0_17", "a18_24", "a25_35", "pwd", "rural", "urban", ...MARGINALIZED].forEach(k => { u[k] = n(e[k]); });
    out.push(u);
  }
  return out;
}

/**
 * evsByProgram: { ai_native: [docs], ai_foundation: [...], ai_deep: [...] }
 * programs: config list [{ key, label, commitment }]
 * projectConfig: the calendar's udaan_config/project_tracking document (or null)
 */
export function computeTracking(evsByProgram, programs, projectConfig) {
  const result = { programs: {}, totals: null, computedAt: new Date().toISOString() };
  const tByPY = (projectConfig && projectConfig.targetsByProgramYear) || {};
  const tot = { trained: 0, pipeline: 0, women: 0, genderKnown: 0, rural: 0, pwd: 0, marginalized: 0, youth: 0, completedCohorts: 0 };

  for (const p of programs) {
    const us = units(evsByProgram[p.key] || []);
    const s = { key: p.key, label: p.label, commitment: p.commitment, trained: 0, pipeline: 0, completedCohorts: 0, pipelineCohorts: 0,
      byYear: {}, calendarTargets: {}, calendarTargetTotal: 0, women: 0, genderKnown: 0, rural: 0, pwd: 0, marginalized: 0, youth: 0,
      provinces: {}, sectors: {}, lastChange: "", records: us.length };
    for (const u of us) {
      if (u.status === "cancelled") continue;
      if (u.done) {
        s.trained += u.trained; s.completedCohorts++;
        if (u.year) s.byYear[u.year] = (s.byYear[u.year] || 0) + u.trained;
        s.women += u.women; s.genderKnown += GENDER.reduce((a, k) => a + u[k], 0);
        s.rural += u.rural; s.pwd += u.pwd; s.youth += u.a18_24 + u.a25_35;
        s.marginalized += MARGINALIZED.reduce((a, k) => a + u[k], 0);
        if (u.province) s.provinces[u.province] = (s.provinces[u.province] || 0) + u.trained;
        if (u.sector) s.sectors[u.sector] = (s.sectors[u.sector] || 0) + u.trained;
      } else if (PIPELINE.includes(u.status)) {
        s.pipeline += u.planned; s.pipelineCohorts++;
      }
      if (u.changedAt && String(u.changedAt) > s.lastChange) s.lastChange = String(u.changedAt);
    }
    const yt = tByPY[p.key] || p.defaultYears || {};
    for (const y in yt) { const v = n(yt[y]); s.calendarTargets[y] = v; s.calendarTargetTotal += v; }
    result.programs[p.key] = s;
    tot.trained += s.trained; tot.pipeline += s.pipeline; tot.women += s.women; tot.genderKnown += s.genderKnown;
    tot.rural += s.rural; tot.pwd += s.pwd; tot.marginalized += s.marginalized; tot.youth += s.youth; tot.completedCohorts += s.completedCohorts;
  }
  result.totals = tot;
  return result;
}

/** Share of the given calendar year that has passed (0..1). */
export function yearElapsed(year, now = new Date()) {
  const start = new Date(year, 0, 1), end = new Date(year + 1, 0, 1);
  return Math.max(0, Math.min(1, (now - start) / (end - start)));
}
