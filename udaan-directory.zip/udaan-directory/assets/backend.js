/* Backend helpers. Firebase is only downloaded when config.js has a firebase block,
   so the read-only directory stays fast and works with no backend at all. */

const FIREBASE_VERSION = "10.12.2";
const sdk = name => import(`https://www.gstatic.com/firebasejs/${FIREBASE_VERSION}/firebase-${name}.js`);

/**
 * Connects Firebase. Returns null when no config is set.
 * handlers: { onUser(user|null), onProgress(map), onCustom(list), onError(err) }
 */
export async function initBackend(cfg, handlers) {
  if (!cfg || !cfg.firebase) return null;
  const [{ initializeApp }, A, F] = await Promise.all([sdk("app"), sdk("auth"), sdk("firestore")]);
  const app = initializeApp(cfg.firebase);
  const auth = A.getAuth(app);
  const db = F.getFirestore(app);
  let unsubs = [];

  A.onAuthStateChanged(auth, user => {
    unsubs.forEach(u => u()); unsubs = [];
    handlers.onUser(user);
    if (!user) { handlers.onProgress({}); handlers.onCustom([]); return; }
    // One listener per collection for the whole session.
    unsubs.push(F.onSnapshot(F.collection(db, "progress"), snap => {
      const map = {}; snap.forEach(d => { map[d.id] = d.data(); }); handlers.onProgress(map);
    }, handlers.onError));
    unsubs.push(F.onSnapshot(F.collection(db, "custom"), snap => {
      const list = []; snap.forEach(d => list.push(Object.assign({ id: d.id }, d.data()))); handlers.onCustom(list);
    }, handlers.onError));
  });

  return {
    signIn: (email, pass) => A.signInWithEmailAndPassword(auth, email, pass),
    signOut: () => A.signOut(auth),
    saveProgress: (id, data) => F.setDoc(F.doc(db, "progress", id), data),
    addCustom: data => F.addDoc(F.collection(db, "custom"), data),
    idToken: () => auth.currentUser ? auth.currentUser.getIdToken() : Promise.resolve(null)
  };
}

/**
 * Streams an answer from the chat worker. Yields the whole answer so far after each chunk.
 * The worker relays Anthropic's server-sent events unchanged.
 */
export async function* streamChat(url, token, system, messages, signal) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) },
    body: JSON.stringify({ system, messages }),
    signal
  });
  if (!res.ok || !res.body) {
    let msg = "The assistant is unavailable (" + res.status + ").";
    try { const j = await res.json(); if (j && j.error) msg = j.error; } catch (e) {}
    throw new Error(msg);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "", text = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let cut;
    while ((cut = buf.indexOf("\n\n")) >= 0) {
      const block = buf.slice(0, cut); buf = buf.slice(cut + 2);
      for (const line of block.split("\n")) {
        if (!line.startsWith("data:")) continue;
        let ev; try { ev = JSON.parse(line.slice(5).trim()); } catch (e) { continue; }
        if (ev.type === "content_block_delta" && ev.delta && ev.delta.type === "text_delta") { text += ev.delta.text; yield text; }
        else if (ev.type === "error") throw new Error((ev.error && ev.error.message) || "The assistant stopped with an error.");
      }
    }
  }
  return text;
}

/**
 * Read-only live link to the Cohort Calendar's Firestore (a separate Firebase project).
 * Runs as a second, named Firebase app so it never interferes with the directory's own login.
 * If the calendar and the directory share one project, the existing app is reused.
 * handlers: { onEvents(programKey, docs), onConfig(data|null), onError(err) }
 */
export async function initCohort(cohort, handlers) {
  if (!cohort || !cohort.firebase || !cohort.firebase.projectId) return null;
  const [AppMod, F] = await Promise.all([sdk("app"), sdk("firestore")]);
  // Reuse an app already pointing at this project (the directory's own, or one from an earlier connect).
  const apps = AppMod.getApps();
  const same = apps.find(a => a.options && a.options.projectId === cohort.firebase.projectId);
  const name = "cohort-" + cohort.firebase.projectId;
  const app = same || apps.find(a => a.name === name) || AppMod.initializeApp(cohort.firebase, name);
  const db = F.getFirestore(app);
  const unsubs = [];
  for (const p of cohort.programs || []) {
    unsubs.push(F.onSnapshot(F.collection(db, p.collection), snap => {
      const docs = []; snap.forEach(d => docs.push(Object.assign({ id: d.id }, d.data())));
      handlers.onEvents(p.key, docs);
    }, err => handlers.onError(err)));
  }
  if (cohort.configDoc) {
    const [col, id] = cohort.configDoc.split("/");
    unsubs.push(F.onSnapshot(F.doc(db, col, id), snap => handlers.onConfig(snap.exists() ? snap.data() : null), () => handlers.onConfig(null)));
  }
  return { stop: () => unsubs.forEach(u => u()) };
}

/**
 * Reads the Cohort Calendar's own index.html from GitHub and extracts its live settings:
 * Firebase project, program collections and master yearly targets. Nothing is executed;
 * values are pulled out with patterns. Cached for 12 hours so the 900 KB file isn't fetched
 * on every visit. Returns null if the file can't be read or parsed.
 */
export async function detectCalendarSettings(sourceUrl, maxAgeMs = 12 * 3600 * 1000) {
  const KEY = "udaan-cal-settings";
  let cached = null;
  try { cached = JSON.parse(localStorage.getItem(KEY) || "null"); } catch (e) {}
  if (cached && cached.url === sourceUrl && Date.now() - cached.at < maxAgeMs) return cached.data;
  try {
    const res = await fetch(sourceUrl, { cache: "no-cache" });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const html = await res.text();
    const cfgBlock = (/const\s+FIREBASE_CONFIG\s*=\s*\{([\s\S]*?)\}/.exec(html) || [])[1] || "";
    const firebase = {};
    for (const m of cfgBlock.matchAll(/(\w+)\s*:\s*["']([^"']*)["']/g)) firebase[m[1]] = m[2];
    const progBlock = (/const\s+PROGRAMS\s*=\s*\[([\s\S]*?)\];/.exec(html) || [])[1] || "";
    const programs = [];
    for (const m of progBlock.matchAll(/key\s*:\s*['"]([^'"]+)['"]\s*,\s*label\s*:\s*['"]([^'"]+)['"]\s*,\s*collection\s*:\s*['"]([^'"]+)['"]/g))
      programs.push({ key: m[1], label: m[2], collection: m[3] });
    const tgtBlock = (/const\s+MASTER_TARGETS\s*=\s*\{([\s\S]*?)\n\};/.exec(html) || [])[1] || "";
    const years = {};
    for (const m of tgtBlock.matchAll(/(\w+)\s*:\s*\{[^{}]*years\s*:\s*\{([^}]*)\}/g)) {
      years[m[1]] = {}; for (const y of m[2].matchAll(/(\d{4})\s*:\s*(\d+)/g)) years[m[1]][y[1]] = Number(y[2]);
    }
    if (!firebase.projectId || !programs.length) throw new Error("settings not found");
    const data = { firebase, programs, years };
    try { localStorage.setItem(KEY, JSON.stringify({ url: sourceUrl, at: Date.now(), data })); } catch (e) {}
    return data;
  } catch (e) {
    return cached && cached.url === sourceUrl ? cached.data : null;   // fall back to the last good copy
  }
}
