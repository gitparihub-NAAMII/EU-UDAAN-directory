/* UDAAN commitments directory: plain JavaScript, no framework, no build step. */
import { P, PKEYS, GROUPS, C, WATCH, WATCH_REL } from "./data.js";
import { initBackend, initCohort, detectCalendarSettings, streamChat } from "./backend.js";
import { computeTracking, yearElapsed } from "./tracking.js";

const CFG = window.UDAAN_CONFIG || {};
const STATUS = {
  not_started: { label: "Not started", c: "var(--idle)" },
  in_progress: { label: "In progress", c: "var(--eu)" },
  on_track:    { label: "On track",    c: "var(--ok)" },
  at_risk:     { label: "At risk",     c: "var(--bad)" },
  done:        { label: "Done",        c: "var(--ok)" }
};
const COMPS = [
  { id: "Pathshala",  blurb: "Skills schools and learning platforms",           outs: ["1.1", "1.2"] },
  { id: "Karyashala", blurb: "Bootcamps, hackathons and incubation",            outs: ["2.1", "2.2"] },
  { id: "Karmashala", blurb: "Internships, fellowships and Innovation Fellows", outs: ["2.3"] },
  { id: "Nitishala",  blurb: "Policy, hubs, schools, podcast and carnival",      outs: ["3.1"] }
];
const COMP_OPTIONS = ["Pathshala", "Karyashala", "Karmashala", "Nitishala", "Outcome targets", "Management", "Added"];
const GROUP_BY_ID = new Map(GROUPS.map(g => [g.id, g]));
const COHORT = CFG.cohortCalendar || null;   // settings from config.js
let CAL = COHORT;                             // effective settings, refreshed from the calendar's own repo when connected
const buildTrackMap = cal => new Map(((cal && cal.programs) || []).filter(p => p.commitment).map(p => [p.commitment, p.key]));
let TRACK = buildTrackMap(CAL);               // commitment id -> calendar program key
const PREF_KEY = "udaan-track-on";
const storedPref = (() => { try { return localStorage.getItem(PREF_KEY); } catch (e) { return null; } })();

/* ---------- State ---------- */
const S = {
  progress: {}, custom: [], api: null, user: null, canWrite: false, accessError: "",
  dirty: false, chat: [], busy: false, ctrl: null,
  cohortRaw: {}, cohortConfig: null, track: null, trackState: "off", trackError: "",
  trackOn: COHORT ? (storedPref == null ? !!COHORT.defaultOn : storedPref === "1") : false,
  trackGen: 0, cohortConn: null, lastSync: null, calDetected: false
};
let LIST = [], BY_ID = new Map(), HAY = new Map();   // derived, rebuilt only when data changes

/* ---------- Helpers ---------- */
const $ = s => document.querySelector(s);
function el(tag, attrs, ...kids) {
  const n = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    const v = attrs[k];
    if (v == null || v === false) continue;
    if (k === "class") n.className = v;
    else if (k === "style") n.setAttribute("style", v);
    else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat(Infinity)) { if (k == null || k === false) continue; n.append(k.nodeType ? k : document.createTextNode(String(k))); }
  return n;
}
const fmt = n => n == null || n === "" || isNaN(n) ? "—" : Number(n).toLocaleString("en-US", { maximumFractionDigits: 2 });
const esc = s => String(s == null ? "" : s).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
const groupOf = id => GROUP_BY_ID.get(id);
const compOf = c => c.g === "CU" ? (c.comp || "Added") : groupOf(c.g).comp;
const pname = k => P[k] ? P[k].name : k;
const when = iso => { try { return new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }); } catch (e) { return ""; } };
const statusOf = c => {
  if (S.progress[c.id] && STATUS[S.progress[c.id].status]) return S.progress[c.id].status;   // a status someone set wins
  const k = TRACK.get(c.id), t = k && S.track ? S.track.programs[k] : null;                   // otherwise derive it from the calendar
  return t ? (t.trained >= c.target ? "done" : t.trained > 0 || t.pipeline > 0 ? "in_progress" : "not_started") : "not_started";
};
/* Live numbers from the Cohort Calendar win over manually logged ones for linked commitments. */
const tracked = c => { const k = TRACK.get(c.id); return k && S.track ? S.track.programs[k] : null; };
const achieved = c => { const t = tracked(c); if (t) return t.trained; const p = S.progress[c.id]; return p && p.achieved != null ? Number(p.achieved) : null; };
const pct = c => { const a = achieved(c); if (a == null || !c.target) return null; return Math.max(0, Math.min(1, a / c.target)); };
const pctTxt = (a, b) => b ? Math.round(a / b * 1000) / 10 + "%" : "—";
const byId = id => BY_ID.get(id);
const all = () => LIST;

function rebuild() {
  const custom = S.custom.map(x => ({
    id: "cu-" + x.id, g: "CU", code: x.code || "Added", title: x.title || "Untitled", lead: [x.lead].filter(k => P[k]), sup: [],
    target: (x.target === "" || x.target == null || isNaN(x.target)) ? null : Number(x.target), unit: x.unit || "", details: x.details || "",
    page: x.source || "", comp: COMP_OPTIONS.includes(x.comp) ? x.comp : "Added", custom: true
  }));
  LIST = C.concat(custom);
  BY_ID = new Map(LIST.map(c => [c.id, c]));
  HAY = new Map(LIST.map(c => {
    const st = S.progress[c.id];
    return [c.id, [c.id, c.code, c.title, c.details, c.unit, c.tier, c.page, compOf(c), (groupOf(c.g) || {}).title,
      ...c.lead.map(k => pname(k) + " " + k), ...c.sup.map(pname), st && st.note, STATUS[statusOf(c)].label, c.target != null ? String(c.target) : ""
    ].join(" ").toLowerCase()];
  }));
}
function partnerProgress(k) {
  const led = LIST.filter(c => c.lead.includes(k)), wt = led.filter(c => c.target != null), up = wt.filter(c => pct(c) != null);
  return { led, wt, up, avg: wt.length ? up.reduce((s, c) => s + pct(c), 0) / wt.length : 0 };
}
const words = q => q.toLowerCase().split(/\s+/).filter(Boolean);

/* ---------- Routing ---------- */
function route() {
  const h = location.hash.replace(/^#\/?/, ""), i = h.indexOf("/");
  return { kind: (i < 0 ? h : h.slice(0, i)) || "home", arg: i < 0 ? "" : decodeURIComponent(h.slice(i + 1)) };
}
function routeLabel(r) {
  switch (r.kind) {
    case "partner": return P[r.arg] ? P[r.arg].name + " partner page" : "Partner page";
    case "comp": return r.arg + " component";
    case "output": return (groupOf(r.arg) || { title: "Output" }).title;
    case "c": { const c = byId(r.arg); return c ? c.code + " " + c.title : "A commitment"; }
    case "status": return (STATUS[r.arg] || { label: "" }).label + " commitments";
    case "search": return "Search results for \"" + r.arg + "\"";
    case "watch": return "Watch-outs";
    case "team": return "Partners and team";
    case "tracking": return "Commitments vs Cohort Calendar tracking";
    case "all": return "All commitments";
    default: return "Overview";
  }
}

/* ---------- Sidebar ---------- */
function renderNav() {
  const r = route(), here = "#/" + (r.kind === "home" ? "" : r.kind + (r.arg ? "/" + encodeURIComponent(r.arg) : ""));
  const cnt = f => LIST.filter(f).length;
  const link = (href, label, count, opt = {}) => el("a", Object.assign({ href, "aria-current": href === here ? "page" : null }, opt.attrs || {}),
    opt.dot ? el("span", { class: "dot", style: "--pc:" + opt.dot }) : null, label, count != null ? el("span", { class: "ct" }, count) : null);
  const f = document.createDocumentFragment();
  f.append(el("h4", null, "Start"), link("#/", "Overview"), link("#/all", "All commitments", LIST.length));
  if (COHORT) f.append(link("#/tracking", "Commitments vs tracking", S.trackOn ? null : "off", { dot: S.trackState === "ok" ? "var(--ok)" : S.trackState === "error" ? "var(--bad)" : "var(--idle)" }));
  f.append(el("h4", null, "By partner"));
  PKEYS.forEach(k => f.append(link("#/partner/" + k, P[k].name, cnt(c => c.lead.includes(k) || c.sup.includes(k)), { dot: P[k].color })));
  f.append(el("h4", null, "By component"));
  COMPS.forEach(cp => {
    f.append(link("#/comp/" + cp.id, cp.id, cnt(c => compOf(c) === cp.id)));
    cp.outs.forEach(o => f.append(link("#/output/" + o, "Output " + o, cnt(c => c.g === o), { attrs: { class: "sub", title: groupOf(o).title } })));
  });
  f.append(link("#/output/OC", "Outcome targets", cnt(c => c.g === "OC")), link("#/output/MG", "Management and reporting", cnt(c => c.g === "MG")));
  if (S.custom.length) f.append(link("#/output/CU", "Added by your team", S.custom.length));
  f.append(el("h4", null, "By status"));
  ["at_risk", "in_progress", "on_track", "not_started", "done"].forEach(s => f.append(link("#/status/" + s, STATUS[s].label, cnt(c => statusOf(c) === s), { dot: STATUS[s].c })));
  f.append(el("h4", null, "Reference"), link("#/watch", "Watch-outs", WATCH.length), link("#/team", "Partners and team"));
  $("#nav").replaceChildren(f);
}

/* ---------- Shared pieces ---------- */
const chip = (k, lead, asLink) => el(asLink ? "a" : "span", { class: "chip" + (lead ? " lead" : ""), href: asLink ? "#/partner/" + k : null, style: "--pc:" + (P[k] ? P[k].color : "var(--eu)"), title: lead ? "Leads" : "Supports" }, pname(k));
function item(c) {
  const st = S.progress[c.id], s = STATUS[statusOf(c)], p = pct(c), lp = P[c.lead[0]];
  return el("a", { class: "item", href: "#/c/" + c.id },
    el("div", { class: "m" },
      el("div", { class: "code" }, c.code + (c.tier ? "  " + c.tier : "")),
      el("div", { class: "t" }, c.title),
      el("div", { class: "chips" }, c.lead.map(k => chip(k, true)), c.sup.map(k => chip(k, false)))),
    el("div", null, el("div", { class: "n" }, c.target == null ? "—" : fmt(c.target)), el("div", { class: "u" }, c.unit || "Status only")),
    el("div", { class: "pg" },
      el("div", { class: "line" }, el("span", { class: "status", style: "--sc:" + s.c }, s.label), c.target != null ? el("span", null, fmt(achieved(c))) : null),
      c.target != null ? el("div", { class: "meter", style: "--pc:" + (c.lead.length === 1 && lp ? lp.color : "var(--eu)") }, el("i", { style: "width:" + Math.round((p || 0) * 100) + "%" })) : null,
      tracked(c) ? el("span", { class: "small live" }, "Live from Cohort Calendar") : el("span", { class: "small" }, st ? "Updated " + when(st.at) : "No updates yet")));
}
function grouped(list, host) {
  if (!list.length) { host.append(el("div", { class: "empty" }, "Nothing here yet.")); return; }
  for (const g of GROUPS) {
    const items = list.filter(c => c.g === g.id); if (!items.length) continue;
    host.append(el("h2", { class: "sec" }, el("span", { class: "comp" }, g.comp), el("a", { href: "#/output/" + g.id, style: "color:inherit;text-decoration:none" }, g.title)),
      el("div", { class: "secmeta" }, g.meta), ...items.map(item));
  }
}
function header(m, crumbs, title, lede) {
  if (crumbs && crumbs.length) m.append(el("div", { class: "crumbs" }, crumbs.map((c, i) => [i ? el("span", null, "›") : null, c[1] ? el("a", { href: c[1] }, c[0]) : el("span", null, c[0])])));
  m.append(el("h1", { class: "page" }, title));
  if (lede) m.append(el("p", { class: "lede" }, lede));
}
function accessBanner(m) {
  if (!S.api) return;
  if (!S.user) m.append(el("div", { class: "banner" }, "You're viewing the signed commitments. ", el("a", { href: "#", onclick: e => { e.preventDefault(); openSignIn(); } }, "Sign in"), " to see and log your team's progress."));
  else if (S.accessError) m.append(el("div", { class: "banner" }, S.accessError));
}

/* ---------- Views ---------- */
function vHome(m) {
  header(m, null, "UDAAN commitments directory", "Everything the four consortium partners signed up to deliver for the EU, who owns it, and how far along it is. Browse from the left, search above, or ask in the panel.");
  accessBanner(m);
  m.append(el("div", { class: "ref" }, "Source: Annex A.2 full application, EuropeAid/183733/DD/ACT/NP, Lot 3 Youth in Digital, 48 months. Page numbers point to that document."));
  m.append(el("h2", { class: "sec" }, "Partners"), el("div", { class: "cards" }, PKEYS.map(k => {
    const pp = partnerProgress(k);
    return el("a", { class: "pcard", href: "#/partner/" + k, style: "--pc:" + P[k].color },
      el("span", { class: "pn" }, P[k].name), el("span", { class: "pr" }, P[k].full),
      el("span", null, el("span", { class: "big" }, pp.led.length), el("span", { class: "small" }, " commitments led")),
      el("span", { class: "meter" }, el("i", { style: "width:" + Math.round(pp.avg * 100) + "%" })),
      el("span", { class: "small" }, pp.up.length ? Math.round(pp.avg * 100) + "% toward targets" : "No progress logged yet"));
  })));
  if (COHORT) {
    m.append(el("h2", { class: "sec" }, el("a", { href: "#/tracking", style: "color:inherit" }, "Project Tracking System")), trackPanel(false));
    if (S.trackState === "ok") m.append(trackCards());
  }
  m.append(el("h2", { class: "sec" }, "Components"), el("div", { class: "cards" }, COMPS.map(cp => el("a", { class: "pcard", href: "#/comp/" + cp.id, style: "--pc:var(--eu)" },
    el("span", { class: "pn" }, cp.id), el("span", { class: "pr" }, cp.blurb), el("span", { class: "small" }, LIST.filter(c => compOf(c) === cp.id).length + " commitments, Outputs " + cp.outs.join(" and "))))));
  const risk = LIST.filter(c => statusOf(c) === "at_risk");
  m.append(el("h2", { class: "sec" }, "Needs attention"));
  if (risk.length) m.append(...risk.map(item));
  else m.append(el("div", { class: "empty" }, "Nothing marked at risk. Mark a commitment at risk from its page and it shows up here."));
  const recent = LIST.filter(c => S.progress[c.id]).sort((a, b) => String(S.progress[b.id].at).localeCompare(String(S.progress[a.id].at))).slice(0, 6);
  m.append(el("h2", { class: "sec" }, "Recently updated"));
  if (recent.length) m.append(...recent.map(item));
  else m.append(el("div", { class: "empty" }, "No progress logged yet. Open any commitment and use Log progress."));
}
function vAll(m) { header(m, [["Overview", "#/"]], "All commitments", LIST.length + " commitments from the signed proposal and your team's additions."); addButton(m); grouped(LIST, m); }
function vPartner(m, k) {
  const p = P[k]; if (!p) return vNotFound(m);
  const led = LIST.filter(c => c.lead.includes(k)), sup = LIST.filter(c => !c.lead.includes(k) && c.sup.includes(k)), pp = partnerProgress(k);
  header(m, [["Overview", "#/"], ["Partners", "#/team"]], p.name, p.full);
  m.append(el("div", { class: "detail" },
    el("div", { class: "panel" }, el("h3", null, "Role in UDAAN"), el("p", { style: "margin:0 0 8px" }, p.role), el("div", { class: "ref" }, "Source: " + p.page)),
    el("div", { class: "panel", style: "border-top:4px solid " + p.color }, el("h3", null, "At a glance"),
      el("dl", { class: "facts" }, el("dt", null, "Leads"), el("dd", null, led.length + " commitments"), el("dt", null, "Supports"), el("dd", null, sup.length + " more"),
        el("dt", null, "Progress"), el("dd", null, pp.up.length ? Math.round(pp.avg * 100) + "% toward targets" : "Nothing logged"),
        el("dt", null, "On the PAT"), el("dd", null, p.pat)))));
  m.append(el("h2", { class: "sec" }, "Leads")); grouped(led, m);
  if (sup.length) m.append(el("h2", { class: "sec" }, "Supports"), el("div", { class: "secmeta" }, "Another partner leads these, with " + p.name + " contributing."), ...sup.map(item));
  m.append(el("h2", { class: "sec" }, "Team"), el("div", { class: "teamgrid" }, el("div", { class: "tcard", style: "--pc:" + p.color },
    el("h4", { style: "margin-top:0" }, "Implementation team"), el("ul", null, p.team.map(t => el("li", null, t))),
    el("h4", null, "Finance"), el("ul", null, p.fin.map(t => el("li", null, t))), el("div", { class: "ref" }, "Source: Figure 2, p.20"))));
}
function vComp(m, id) {
  const cp = COMPS.find(x => x.id === id); if (!cp) return vNotFound(m);
  header(m, [["Overview", "#/"]], cp.id, cp.blurb + "."); grouped(LIST.filter(c => compOf(c) === cp.id), m);
}
function vOutput(m, id) {
  const g = groupOf(id); if (!g) return vNotFound(m);
  const cp = COMPS.find(x => x.outs.includes(id));
  header(m, [["Overview", "#/"], cp ? [cp.id, "#/comp/" + cp.id] : null].filter(Boolean), g.title, g.meta);
  if (id === "CU") addButton(m);
  const list = LIST.filter(c => c.g === id);
  if (!list.length) m.append(el("div", { class: "empty" }, id === "CU" ? "No added commitments yet. Use Add commitment to bring in targets from the logframe, budget or partnership agreements." : "Nothing here yet."));
  else m.append(...list.map(item));
}
function vStatus(m, s) {
  if (!STATUS[s]) return vNotFound(m);
  const list = LIST.filter(c => statusOf(c) === s);
  header(m, [["Overview", "#/"]], STATUS[s].label, list.length + " commitments."); grouped(list, m);
}
function vDetail(m, id) {
  const c = byId(id); if (!c) return vNotFound(m);
  const g = groupOf(c.g), cp = COMPS.find(x => x.outs.includes(c.g)), st = S.progress[c.id], s = STATUS[statusOf(c)], p = pct(c), lp = P[c.lead[0]];
  header(m, [["Overview", "#/"], cp ? [cp.id, "#/comp/" + cp.id] : null, [/^\d/.test(g.id) ? "Output " + g.id : g.title, "#/output/" + g.id], [c.code]].filter(Boolean), c.title);
  m.append(el("div", { class: "chips", style: "margin-bottom:16px" }, c.lead.map(k => chip(k, true, true)), c.sup.map(k => chip(k, false, true))));
  const left = el("div", { style: "display:grid;gap:14px" },
    el("div", { class: "panel" }, el("h3", null, "What was promised"), el("dl", { class: "facts" },
      el("dt", null, "Activity"), el("dd", null, c.code + (c.tier ? ", " + c.tier : "")),
      el("dt", null, "Component"), el("dd", null, compOf(c)),
      el("dt", null, "Lead"), el("dd", null, c.lead.map(pname).join(", ") || "—"),
      el("dt", null, "Supporting"), el("dd", null, c.sup.map(pname).join(", ") || "None named"),
      el("dt", null, "Target"), el("dd", null, c.target == null ? "Status only" : fmt(c.target) + " " + c.unit),
      c.details ? [el("dt", null, "Details"), el("dd", null, c.details)] : null,
      el("dt", null, "Source"), el("dd", null, c.page || "—"))));
  WATCH.forEach((w, i) => { if ((WATCH_REL[i] || []).includes(c.id)) left.append(el("div", { class: "wo" }, el("h3", null, w.t), el("p", null, w.p), el("p", { class: "ask-line" }, w.a), el("div", { class: "ref" }, "Source: " + w.pages))); });
  left.append(editor(c, st));
  const hist = (st && st.history) || [];
  left.append(el("div", { class: "panel" }, el("h3", null, "History"), hist.length
    ? el("div", { class: "history" }, hist.map(h => el("div", null, el("strong", null, when(h.at)), " ", h.byName || "A teammate", ": ", h.achieved != null ? fmt(h.achieved) + ", " : "", STATUS[h.status] ? STATUS[h.status].label : "", h.note ? ". " + h.note : "")))
    : el("div", { class: "small" }, S.user || !S.api ? "No updates yet." : "Sign in to see the history.")));
  const right = el("div", { style: "display:grid;gap:14px" },
    el("div", { class: "panel", style: "border-top:4px solid " + (lp ? lp.color : "var(--eu)") }, el("h3", null, "Progress"),
      el("div", { class: "bigtarget" }, c.target == null ? s.label : fmt(achieved(c))),
      c.target != null ? el("div", { class: "small", style: "margin:4px 0 10px" }, "of " + fmt(c.target) + " " + c.unit) : null,
      c.target != null ? el("div", { class: "meter", style: "--pc:" + (lp ? lp.color : "var(--eu)") }, el("i", { style: "width:" + Math.round((p || 0) * 100) + "%" })) : null,
      el("div", { style: "margin-top:10px" }, el("span", { class: "status", style: "--sc:" + s.c }, s.label)),
      st && st.note ? el("p", { style: "font-size:14px;margin:10px 0 0" }, st.note) : null,
      el("div", { class: "small", style: "margin-top:8px" }, st ? "Status updated " + when(st.at) + " by " + (st.byName || "a teammate") : "No updates yet")));
  if (TRACK.has(c.id)) right.append(livePanel(c));
  const sibs = LIST.filter(x => x.id !== c.id && x.g === c.g && (x.code === c.code || x.lead.some(k => c.lead.includes(k)))).slice(0, 6);
  if (sibs.length) right.append(el("div", { class: "panel" }, el("h3", null, "Related"), el("div", { style: "display:grid;gap:6px" }, sibs.map(x => el("a", { href: "#/c/" + x.id, style: "font-size:14px" }, x.code + " " + x.title)))));
  right.append(el("button", { class: "btn", onclick: () => { openChat(); send("Tell me everything about " + c.code + " " + c.title + ": who owns it, the target, progress and anything to watch out for."); } }, "Ask about this"));
  m.append(el("div", { class: "detail" }, left, right));
}
function editor(c, st) {
  const box = el("div", { class: "panel" }, el("h3", null, "Log progress"));
  if (!S.api) { box.append(el("div", { class: "small" }, "Progress logging isn't set up yet. Add your Firebase settings to config.js to turn it on.")); return box; }
  if (!S.user) { box.append(el("div", { class: "small" }, el("a", { href: "#", onclick: e => { e.preventDefault(); openSignIn(); } }, "Sign in"), " to log progress.")); return box; }
  if (!S.canWrite) { box.append(el("div", { class: "small" }, S.accessError || "Your account can't update this directory.")); return box; }
  const ach = el("input", { type: "number", step: "any", min: "0", placeholder: c.target == null ? "Not counted" : "e.g. 1200", disabled: c.target == null });
  if (st && st.achieved != null) ach.value = st.achieved;
  const sel = el("select", null, Object.keys(STATUS).map(k => el("option", { value: k, selected: statusOf(c) === k }, STATUS[k].label)));
  const note = el("textarea", { rows: "2", maxlength: "600", placeholder: "What changed, evidence, next step" });
  [ach, sel, note].forEach(i => i.addEventListener("input", () => { S.dirty = true; }));
  const msg = el("span", { class: "err" }), save = el("button", { class: "btn primary" }, "Save progress");
  save.addEventListener("click", async () => {
    const raw = ach.value.trim(), achieved = raw === "" ? null : Number(raw);
    if (raw !== "" && (isNaN(achieved) || achieved < 0)) { msg.textContent = "Enter a number of zero or more."; return; }
    save.disabled = true; msg.textContent = "";
    const entry = { achieved, status: sel.value, note: note.value.trim().slice(0, 600), by: S.user.uid, byName: displayName(), at: new Date().toISOString() };
    try {
      await S.api.saveProgress(c.id, Object.assign({}, entry, { history: [entry].concat((st && st.history) || []).slice(0, 30) }));
      S.dirty = false; renderAll();
    } catch (e) {
      save.disabled = false;
      msg.textContent = e && e.code === "permission-denied" ? "Your account isn't on the team list, so it can't save." : "Couldn't save. Check your connection and try again.";
    }
  });
  box.append(el("div", { class: "form" }, el("div", { class: "fields" }, el("label", null, "Achieved so far", ach), el("label", null, "Status", sel)),
    el("label", null, "Note", note), el("div", { class: "acts" }, save, msg)));
  return box;
}
function displayName() { const u = S.user; return (u && (u.displayName || (u.email || "").split("@")[0])) || "A teammate"; }
function addButton(m) {
  if (!S.canWrite) return;
  const host = el("div", { style: "margin:6px 0 4px" });
  const btn = el("button", { class: "btn", onclick: () => { host.replaceChildren(addForm(() => host.replaceChildren(btn))); S.dirty = true; } }, "Add commitment");
  host.append(btn); m.append(host);
}
function addForm(onDone) {
  const f = {
    title: el("input", { maxlength: "200", placeholder: "e.g. Train 30 cooperative staff on GeoKrishi" }),
    lead: el("select", null, PKEYS.map(k => el("option", { value: k }, P[k].name))),
    comp: el("select", null, COMP_OPTIONS.map(c => el("option", { value: c, selected: c === "Added" }, c))),
    code: el("input", { maxlength: "40", placeholder: "e.g. 1.2.3 or PA clause 4" }),
    target: el("input", { type: "number", step: "any", min: "0", placeholder: "Blank if status only" }),
    unit: el("input", { maxlength: "80", placeholder: "e.g. staff trained" }),
    source: el("input", { maxlength: "160", placeholder: "e.g. NAAMII partnership agreement, p.4" }),
    details: el("textarea", { rows: "2", maxlength: "800" })
  };
  const msg = el("span", { class: "err" }), save = el("button", { class: "btn primary" }, "Add to directory");
  save.addEventListener("click", async () => {
    if (!f.title.value.trim()) { msg.textContent = "Give the commitment a title."; return; }
    save.disabled = true;
    try {
      await S.api.addCustom({ title: f.title.value.trim(), lead: f.lead.value, comp: f.comp.value, code: f.code.value.trim(),
        target: f.target.value === "" ? null : Number(f.target.value), unit: f.unit.value.trim(), source: f.source.value.trim(),
        details: f.details.value.trim(), by: S.user.uid, byName: displayName(), at: new Date().toISOString() });
      S.dirty = false; onDone(); renderAll();
    } catch (e) { save.disabled = false; msg.textContent = e && e.code === "permission-denied" ? "Your account isn't on the team list." : "Couldn't add it. Try again."; }
  });
  return el("div", { class: "panel" }, el("h3", null, "Add a commitment from another document"), el("div", { class: "form" },
    el("label", null, "Commitment", f.title),
    el("div", { class: "fields" }, el("label", null, "Lead partner", f.lead), el("label", null, "Component", f.comp), el("label", null, "Reference", f.code),
      el("label", null, "Target", f.target), el("label", null, "Unit", f.unit), el("label", null, "Source document", f.source)),
    el("label", null, "Details", f.details),
    el("div", { class: "acts" }, save, el("button", { class: "btn", onclick: () => { S.dirty = false; onDone(); } }, "Cancel"), msg)));
}
function vSearch(m, q) {
  header(m, [["Overview", "#/"]], "Search");
  const ws = words(q);
  if (!ws.length) { m.append(el("div", { class: "empty" }, "Type a word above: a partner, tier, activity number, place or role.")); return; }
  const cs = LIST.filter(c => { const h = HAY.get(c.id); return ws.every(w => h.includes(w)); });
  const ps = PKEYS.filter(k => { const h = [k, P[k].name, P[k].full, P[k].role, P[k].pat, ...P[k].team, ...P[k].fin].join(" ").toLowerCase(); return ws.every(w => h.includes(w)); });
  const roles = []; PKEYS.forEach(k => P[k].team.concat(P[k].fin).forEach(t => { if (ws.every(w => (t + " " + P[k].name).toLowerCase().includes(w))) roles.push([k, t]); }));
  const wos = WATCH.filter(w => ws.every(x => (w.t + " " + w.p + " " + w.a).toLowerCase().includes(x)));
  const total = cs.length + ps.length + roles.length + wos.length;
  m.append(el("p", { class: "lede" }, total ? total + " results for \u201C" + q + "\u201D." : "No matches for \u201C" + q + "\u201D. Try fewer words, or ask in the panel."));
  if (!total) m.append(el("button", { class: "btn primary", onclick: () => { openChat(); send(q); } }, "Ask the register instead"));
  if (cs.length) m.append(el("h2", { class: "sec" }, "Commitments"), ...cs.map(item));
  if (ps.length) m.append(el("h2", { class: "sec" }, "Partners"), ...ps.map(k => el("a", { class: "reshit", href: "#/partner/" + k }, el("strong", null, P[k].name), el("span", { class: "small" }, P[k].role))));
  if (roles.length) m.append(el("h2", { class: "sec" }, "Team roles"), ...roles.map(([k, t]) => el("a", { class: "reshit", href: "#/partner/" + k }, el("strong", null, t), el("span", { class: "small" }, P[k].name))));
  if (wos.length) m.append(el("h2", { class: "sec" }, "Watch-outs"), ...wos.map(w => el("a", { class: "reshit", href: "#/watch" }, el("strong", null, w.t), el("span", { class: "small" }, w.p))));
}
function vWatch(m) {
  header(m, [["Overview", "#/"]], "Watch-outs", "Places where the proposal contradicts itself or leaves a number open. Settle these in the PIT before they reach an EU report.");
  WATCH.forEach((w, i) => m.append(el("div", { class: "wo" }, el("h3", null, w.t), el("p", null, w.p), el("p", { class: "ask-line" }, w.a),
    el("div", { class: "ref" }, "Source: " + w.pages, (WATCH_REL[i] || []).length ? ". Affects: " : "",
      (WATCH_REL[i] || []).map((id, j) => { const c = byId(id); return c ? [j ? ", " : "", el("a", { href: "#/c/" + id }, c.code + " " + c.title)] : null; })))));
}
function vTeam(m) {
  header(m, [["Overview", "#/"]], "Partners and team", "Who sits where in the consortium. Source: Figure 2, p.20, and partner roles p.20 to 21.");
  m.append(el("h2", { class: "sec" }, "48-month shape"), el("div", { class: "secmeta" }, "The start date isn't in this document, so months count from contract start. p.8"),
    el("div", { class: "timeline" }, el("div", null, el("b", null, "Months 1 to 6"), "Preparatory: agreements, recruitment, curricula, baseline"),
      el("div", null, el("b", null, "Months 7 to 42"), "Three 12-month implementation cycles across all four components"),
      el("div", null, el("b", null, "Months 43 to 48"), "Closure, evaluation, handover")),
    el("h2", { class: "sec" }, "Governance"), el("div", { class: "secmeta" }, "Project Accountability Team: heads of all four organisations, at least twice a year. Project Implementation Team: programme staff from every partner, monthly. p.20"),
    el("div", { class: "teamgrid" }, PKEYS.map(k => { const p = P[k];
      return el("div", { class: "tcard", style: "--pc:" + p.color }, el("h3", null, el("a", { href: "#/partner/" + k, style: "color:inherit" }, p.name)), el("div", { class: "small" }, p.full),
        el("p", { style: "font-size:13.5px" }, p.role), el("h4", null, "On the PAT"), el("div", { style: "font-size:13.5px" }, p.pat),
        el("h4", null, "Implementation team"), el("ul", null, p.team.map(t => el("li", null, t))), el("h4", null, "Finance"), el("ul", null, p.fin.map(t => el("li", null, t)))); })));
}
function vNotFound(m) { header(m, [["Overview", "#/"]], "Not found", "That page doesn't exist. Pick something from the directory."); }

/* ---------- Cohort Calendar comparison ---------- */
function recomputeTracking() {
  if (!CAL.programs.every(p => S.cohortRaw[p.key])) return;   // wait until every program has loaded once
  S.track = computeTracking(S.cohortRaw, CAL.programs, S.cohortConfig);
  S.trackState = "ok"; S.trackError = "";
  softRender();
}
const calendarLink = () => CAL && CAL.url ? el("a", { href: CAL.url, target: "_blank", rel: "noopener" }, "Open the Cohort Calendar") : null;
function lastCalendarChange() { return S.track ? Object.values(S.track.programs).map(t => t.lastChange).sort().pop() || "" : ""; }

function trackChecks() {
  const out = []; if (!S.track) return out;
  const now = new Date(), y = now.getFullYear();
  for (const p of CAL.programs) {
    const t = S.track.programs[p.key], c = byId(p.commitment); if (!t || !c) continue;
    if (t.calendarTargetTotal !== c.target)
      out.push({ lvl: "bad", t: p.label + ": calendar targets don't match the EU commitment", p: "The calendar's year targets add up to " + fmt(t.calendarTargetTotal) + ", but the proposal commits to " + fmt(c.target) + ". Fix the targets in the calendar's Settings.", id: c.id });
    else
      out.push({ lvl: "ok", t: p.label + ": calendar targets match the EU commitment", p: Object.entries(t.calendarTargets).map(([yy, v]) => yy + ": " + fmt(v)).join(", ") + " = " + fmt(c.target) + ".", id: c.id });
    const ty = t.calendarTargets[y];
    if (ty) {
      const expected = Math.round(ty * yearElapsed(y, now)), got = t.byYear[y] || 0;
      if (got < expected * 0.9)
        out.push({ lvl: "warn", t: p.label + ": behind the " + y + " plan", p: fmt(got) + " trained in " + y + " against a year target of " + fmt(ty) + ". At an even pace you'd be near " + fmt(expected) + " by today, a gap of " + fmt(expected - got) + ". " + fmt(t.pipeline) + " more are in confirmed, reserved or booked cohorts.", id: c.id });
      else
        out.push({ lvl: "ok", t: p.label + ": on pace for " + y, p: fmt(got) + " trained against an even-pace mark of about " + fmt(expected) + " (year target " + fmt(ty) + ").", id: c.id });
    }
    const st = S.progress[c.id];
    if (st && st.achieved != null && Number(st.achieved) !== t.trained)
      out.push({ lvl: "warn", t: p.label + ": a logged number differs from the calendar", p: fmt(st.achieved) + " was logged in this directory on " + when(st.at) + ", but the calendar shows " + fmt(t.trained) + " trained. The directory uses the calendar figure, so clear or correct the logged number.", id: c.id });
  }
  const T = S.track.totals;
  if (T.genderKnown) {
    const ok = T.women / T.genderKnown >= 0.4;
    out.push({ lvl: ok ? "ok" : "warn", t: ok ? "Women's participation meets the 40% commitment" : "Women's participation is below the 40% commitment",
      p: fmt(T.women) + " women out of " + fmt(T.genderKnown) + " participants with gender recorded (" + pctTxt(T.women, T.genderKnown) + ").", id: "x-women" });
  } else out.push({ lvl: "warn", t: "No gender counts recorded yet", p: "Completed cohorts have no gender data, so the 40% women commitment can't be checked. Fill in the GESI fields when closing a cohort.", id: "x-women" });
  const prov = new Set(); Object.values(S.track.programs).forEach(t => Object.keys(t.provinces).forEach(k => prov.add(k)));
  out.push({ lvl: prov.size >= 7 ? "ok" : "info", t: "Provinces reached: " + prov.size + " of 7", p: (prov.size ? [...prov].sort().join(", ") + ". " : "No province recorded on completed cohorts yet. ") + "The proposal covers all seven provinces (p.4).", id: null });
  return out;
}
function checkCard(x) {
  const color = { ok: "var(--ok)", warn: "var(--warn)", bad: "var(--bad)", info: "var(--eu)" }[x.lvl];
  const c = x.id ? byId(x.id) : null;
  return el("div", { class: "wo", style: "border-left-color:" + color }, el("h3", null, x.t), el("p", null, x.p),
    c ? el("div", { class: "ref" }, "Commitment: ", el("a", { href: "#/c/" + c.id }, c.code + " " + c.title)) : null);
}
function trackCards() {
  if (S.trackState !== "ok") return el("div", { class: "empty" }, S.trackState === "error" ? S.trackError : "Loading cohorts from the calendar…");
  return el("div", { class: "cards" }, CAL.programs.map(p => {
    const t = S.track.programs[p.key], c = byId(p.commitment), tgt = c ? c.target : t.calendarTargetTotal;
    return el("a", { class: "pcard", href: "#/c/" + p.commitment, style: "--pc:" + P.NAAMII.color },
      el("span", { class: "pn" }, p.label), el("span", { class: "pr" }, "EU commitment " + fmt(tgt)),
      el("span", null, el("span", { class: "big" }, fmt(t.trained)), el("span", { class: "small" }, " trained, " + pctTxt(t.trained, tgt))),
      el("span", { class: "meter" }, el("i", { style: "width:" + Math.min(100, Math.round(t.trained / (tgt || 1) * 100)) + "%" })),
      el("span", { class: "small" }, fmt(t.pipeline) + " more in the pipeline"));
  }));
}
function livePanel(c) {
  const box = el("div", { class: "panel", style: "border-top:4px solid var(--ok)" }, el("h3", null, "Live from the Cohort Calendar"));
  if (S.trackState !== "ok") { box.append(el("div", { class: "small" }, trackStatusText()), S.trackOn ? null : el("div", { style: "margin-top:10px" }, switchEl(false))); return box; }
  const t = tracked(c), y = new Date().getFullYear();
  box.append(el("dl", { class: "facts" },
    el("dt", null, "Trained"), el("dd", null, fmt(t.trained) + " in " + t.completedCohorts + " completed cohorts"),
    el("dt", null, "Pipeline"), el("dd", null, fmt(t.pipeline) + " in " + t.pipelineCohorts + " confirmed, reserved or booked cohorts"),
    el("dt", null, "Still to train"), el("dd", null, fmt(Math.max(0, c.target - t.trained)) + " of " + fmt(c.target)),
    t.calendarTargets[y] != null ? [el("dt", null, y + " plan"), el("dd", null, fmt(t.byYear[y] || 0) + " of " + fmt(t.calendarTargets[y]))] : null,
    t.genderKnown ? [el("dt", null, "Women"), el("dd", null, pctTxt(t.women, t.genderKnown) + " of those with gender recorded")] : null),
    el("div", { class: "acts", style: "margin-top:10px;font-size:13.5px" }, el("a", { href: "#/tracking" }, "Full comparison"), calendarLink()));
  return box;
}
function table(head, rows, foot) {
  return el("div", { class: "tablewrap" }, el("table", { class: "cmp" },
    el("thead", null, el("tr", null, head.map((h, i) => el("th", { class: i ? "num" : null }, h)))),
    el("tbody", null, rows.map(r => el("tr", null, r.map((v, i) => el("td", { class: i ? "num" : null }, v))))),
    foot ? el("tfoot", null, el("tr", null, foot.map((v, i) => el("td", { class: i ? "num" : null }, v)))) : null));
}
function vTracking(m) {
  header(m, [["Overview", "#/"]], "Commitments vs Cohort Calendar", "What the consortium committed to the EU, set against what the Cohort Calendar's Project Tracking System shows as actually trained. This page only reads the calendar; it never changes it.");
  m.append(trackPanel(true));
  if (S.trackState !== "ok") return;
  const lc = lastCalendarChange();
  m.append(el("div", { class: "ref", style: "margin-top:10px" }, "Firestore project " + CAL.firebase.projectId + ". Last change in the calendar: " + (lc ? when(lc) : "—") + ". " +
    (S.calDetected ? "Programs, collections and targets are read from the calendar's own GitHub code, so new programs appear here automatically. " : ""), calendarLink()));

  let sum = { eu: 0, cal: 0, tr: 0, pl: 0 };
  const rows = CAL.programs.map(p => {
    const t = S.track.programs[p.key], c = byId(p.commitment), eu = c ? c.target : 0;
    sum.eu += eu; sum.cal += t.calendarTargetTotal; sum.tr += t.trained; sum.pl += t.pipeline;
    return [el("a", { href: "#/c/" + p.commitment }, p.label), fmt(eu),
      t.calendarTargetTotal === eu ? fmt(t.calendarTargetTotal) : el("span", { style: "color:var(--bad);font-weight:600" }, fmt(t.calendarTargetTotal)),
      fmt(t.trained), fmt(t.pipeline), fmt(t.trained + t.pipeline), pctTxt(t.trained, eu), fmt(Math.max(0, eu - t.trained))];
  });
  m.append(el("h2", { class: "sec" }, "AI School tiers"), el("div", { class: "secmeta" }, "Trained counts completed cohorts only. Pipeline is cohorts marked confirmed, reserved or booked. Activity 1.1.1, led by NAAMII."),
    table(["Tier", "EU commitment", "Calendar target", "Trained", "Pipeline", "Trained + pipeline", "Progress", "Still to train"], rows,
      ["Total", fmt(sum.eu), fmt(sum.cal), fmt(sum.tr), fmt(sum.pl), fmt(sum.tr + sum.pl), pctTxt(sum.tr, sum.eu), fmt(Math.max(0, sum.eu - sum.tr))]));

  const years = [...new Set(CAL.programs.flatMap(p => Object.keys(S.track.programs[p.key].calendarTargets)))].sort();
  if (years.length) m.append(el("h2", { class: "sec" }, "Year by year"), el("div", { class: "secmeta" }, "Trained out of the calendar's target for each year."),
    table(["Tier", ...years], CAL.programs.map(p => { const t = S.track.programs[p.key];
      return [p.label, ...years.map(y => fmt(t.byYear[y] || 0) + " / " + fmt(t.calendarTargets[y] || 0))]; })));

  m.append(el("h2", { class: "sec" }, "Checks"), ...trackChecks().sort((a, b) => ["bad", "warn", "info", "ok"].indexOf(a.lvl) - ["bad", "warn", "info", "ok"].indexOf(b.lvl)).map(checkCard));

  const T = S.track.totals;
  m.append(el("h2", { class: "sec" }, "Inclusion (completed cohorts)"), el("div", { class: "secmeta" }, "From the GESI fields filled in on each cohort. Commitments: at least 40% women; priority for marginalised groups (p.12, 27)."),
    table(["Measure", "People", "Share of trained"], [
      ["Women", fmt(T.women), T.genderKnown ? pctTxt(T.women, T.genderKnown) + " of gender recorded" : "No gender data"],
      ["Youth aged 18 to 35", fmt(T.youth), pctTxt(T.youth, T.trained)],
      ["Rural (more than 3h to HQ)", fmt(T.rural), pctTxt(T.rural, T.trained)],
      ["People with disabilities", fmt(T.pwd), pctTxt(T.pwd, T.trained)],
      ["Marginalised caste or ethnic groups", fmt(T.marginalized), pctTxt(T.marginalized, T.trained)]]));

  const agg = key => { const o = {}; Object.values(S.track.programs).forEach(t => Object.entries(t[key]).forEach(([k, v]) => { o[k] = (o[k] || 0) + v; })); return Object.entries(o).sort((a, b) => b[1] - a[1]); };
  const prov = agg("provinces"), sec = agg("sectors");
  if (prov.length) m.append(el("h2", { class: "sec" }, "By province"), table(["Province", "Trained"], prov.map(([k, v]) => [k, fmt(v)])));
  if (sec.length) m.append(el("h2", { class: "sec" }, "By sector"), table(["Sector", "Trained"], sec.map(([k, v]) => [k, fmt(v)])));
}
function trackingText() {
  if (!S.track) return "";
  return "\n\nLIVE COHORT CALENDAR TRACKING (actual delivery, read " + when(S.track.computedAt) + ")\n" +
    CAL.programs.map(p => { const t = S.track.programs[p.key], c = byId(p.commitment);
      return "- " + p.label + " {" + p.commitment + "}: EU commitment " + fmt(c && c.target) + "; calendar target " + fmt(t.calendarTargetTotal) +
        " (" + Object.entries(t.calendarTargets).map(([a, b]) => a + ": " + fmt(b)).join(", ") + "); trained " + fmt(t.trained) + " in " + t.completedCohorts +
        " completed cohorts; pipeline " + fmt(t.pipeline) + "; trained by year " + (Object.entries(t.byYear).map(([a, b]) => a + ": " + fmt(b)).join(", ") || "none") +
        "; women " + t.women + " of " + t.genderKnown + " with gender recorded"; }).join("\n") +
    "\nChecks: " + trackChecks().map(x => x.t).join("; ") +
    "\nFor AI Native, AI Foundation and AI Deep, these calendar figures are the actual progress; prefer them over manually logged numbers.";
}

/* ---------- Connect / disconnect the Project Tracking System ---------- */
function mergeSettings(det) {
  if (!det) return COHORT;
  const byKey = new Map((COHORT.programs || []).map(p => [p.key, p]));
  const guess = label => /native/i.test(label) ? "ai-native" : /foundation/i.test(label) ? "ai-foundation" : /deep/i.test(label) ? "ai-deep" : null;
  return Object.assign({}, COHORT, {
    firebase: Object.assign({}, COHORT.firebase, det.firebase),
    programs: det.programs.map(p => { const base = byKey.get(p.key) || {};
      return { key: p.key, label: p.label, collection: p.collection, commitment: base.commitment || guess(p.label), defaultYears: (det.years && det.years[p.key]) || base.defaultYears }; })
  });
}
async function connectTracking() {
  const gen = ++S.trackGen;
  S.trackState = "loading"; S.trackError = ""; softRender();
  try {
    if (COHORT.autoDetectFrom) {
      const det = await detectCalendarSettings(COHORT.autoDetectFrom);
      if (gen !== S.trackGen) return;
      CAL = mergeSettings(det); TRACK = buildTrackMap(CAL); S.calDetected = !!det;
    }
    const conn = await initCohort(CAL, {
      onEvents(key, docs) { if (gen !== S.trackGen) return; S.cohortRaw[key] = docs; S.lastSync = new Date(); recomputeTracking(); },
      onConfig(data) { if (gen !== S.trackGen) return; S.cohortConfig = data; recomputeTracking(); },
      onError(err) {
        if (gen !== S.trackGen) return;
        S.trackState = "error";
        S.trackError = err && err.code === "permission-denied"
          ? "The Cohort Calendar database refused the read. If its rules now require sign-in, give this site read access (see README)."
          : "Couldn't reach the Cohort Calendar database. Check your connection.";
        softRender();
      }
    });
    if (gen !== S.trackGen) { if (conn) conn.stop(); return; }
    S.cohortConn = conn;
  } catch (e) {
    if (gen === S.trackGen) { S.trackState = "error"; S.trackError = "Couldn't connect to the Cohort Calendar."; softRender(); }
  }
}
function disconnectTracking() {
  S.trackGen++;
  if (S.cohortConn) S.cohortConn.stop();
  Object.assign(S, { cohortConn: null, cohortRaw: {}, cohortConfig: null, track: null, trackState: "off", trackError: "", lastSync: null });
  softRender();
}
function setTrackOn(on) {
  S.trackOn = on;
  try { localStorage.setItem(PREF_KEY, on ? "1" : "0"); } catch (e) {}
  if (on) connectTracking(); else disconnectTracking();
}
function trackStatusText() {
  if (!S.trackOn) return "Off. Commitments show only the progress your team logs by hand.";
  if (S.trackState === "error") return S.trackError;
  if (S.trackState !== "ok") return "Connecting to the Cohort Calendar…";
  return "Live. Any change in the Cohort Calendar shows here within seconds, with no refresh." + (S.lastSync ? " Last update " + S.lastSync.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) + "." : "");
}
function switchEl(big) {
  return el("button", { class: "switch" + (big ? " big" : ""), role: "switch", "aria-checked": S.trackOn ? "true" : "false", onclick: () => setTrackOn(!S.trackOn) },
    el("span", { class: "knob", "aria-hidden": "true" }), el("span", null, "Connect with Project Tracking System"));
}
function trackPanel(big) {
  return el("div", { class: "panel trackpanel" + (S.trackState === "ok" ? " on" : "") },
    el("div", { class: "acts", style: "justify-content:space-between" }, switchEl(true),
      S.trackState === "ok" ? el("span", { class: "livebadge" }, el("i"), "Live") : null),
    el("p", { class: "small", style: "margin:10px 0 0" }, trackStatusText()),
    big && !S.trackOn ? el("p", { class: "small", style: "margin:6px 0 0" }, "When it's on, the directory pulls every cohort from the Cohort Calendar (AI Native, AI Foundation and AI Deep), counts people trained the same way its Master Dashboard does, and compares the numbers with what the consortium committed to the EU. It only reads; it never changes the calendar.") : null);
}
function renderSwitch() {
  const b = $("#trackSwitch"); if (!b) return;
  b.hidden = !COHORT;
  b.setAttribute("aria-checked", S.trackOn ? "true" : "false");
  b.title = trackStatusText();
  b.classList.toggle("err", S.trackState === "error");
}

const VIEWS = { home: vHome, all: vAll, partner: vPartner, comp: vComp, output: vOutput, status: vStatus, c: vDetail, search: vSearch, watch: vWatch, team: vTeam, tracking: vTracking };
function renderMain() {
  const r = route(), m = document.createDocumentFragment();
  (VIEWS[r.kind] || vNotFound)(m, r.arg);
  $("#main").replaceChildren(m);
  if (r.kind !== "search") $("#q").value = "";
  $("#chatCtx").textContent = "Viewing: " + routeLabel(r);
}
function renderAuth() {
  const b = $("#authBtn");
  if (!S.api) { b.hidden = true; return; }
  b.hidden = false;
  b.replaceChildren(S.user ? el("span", { class: "who" }, "Sign out " + (S.user.email || "")) : "Sign in");
}
function renderAll() { renderNav(); renderMain(); renderAuth(); renderSwitch(); }
let rafId = 0;
function softRender() { // coalesces bursts of data updates into one paint
  if (rafId) return;
  rafId = requestAnimationFrame(() => { rafId = 0; rebuild(); renderNav(); renderAuth(); renderSwitch(); if (!S.dirty) renderMain(); });
}

/* ---------- Chat ---------- */
function suggestions() {
  const r = route(), base = ["Has NAAMII committed to anything in animation?", "What numbers do we need for AI Native, AI Foundation and AI Deep?", "Which commitments are at risk or not started?"];
  if (r.kind === "partner" && P[r.arg]) base.unshift("Summarise everything " + P[r.arg].name + " has to deliver, with targets.");
  else if (r.kind === "comp") base.unshift("Who owns what under " + r.arg + "?");
  else if (r.kind === "c" && byId(r.arg)) base.unshift("What should we watch out for on " + byId(r.arg).code + "?");
  else base.push("Who supports the internships and fellowships, and how many?");
  return base.slice(0, 4);
}
function md(text) {
  const lines = esc(text || "").split(/\n/); let html = "", list = false;
  for (let line of lines) {
    line = line.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/\[\[([A-Za-z0-9\-]+)\]\]/g, (x, id) => { const c = byId(id); return c ? '<a class="clink" href="#/c/' + id + '">' + esc(c.code) + "</a>" : ""; });
    const b = line.match(/^\s*[-*•]\s+(.*)/);
    if (b) { if (!list) { html += "<ul>"; list = true; } html += "<li>" + b[1] + "</li>"; continue; }
    if (list) { html += "</ul>"; list = false; }
    if (line.trim()) html += "<p>" + line.replace(/^#+\s*/, "") + "</p>";
  }
  return html + (list ? "</ul>" : "");
}
function renderChat() {
  const box = $("#msgs"), f = document.createDocumentFragment();
  if (!S.chat.length) {
    f.append(el("div", { class: "msg" }, el("p", null, CFG.chatProxyUrl
      ? "Ask about any partner, tier, target or activity. Answers come only from this directory and logged progress, with links to each commitment."
      : "Ask about any partner, tier, target or activity. Answers come straight from the directory and the live Cohort Calendar numbers, with links to each commitment.")),
      el("div", { class: "suggest", style: "padding:0" }, suggestions().map(s => el("button", { onclick: () => send(s), disabled: S.busy }, s))));
  }
  for (const msg of S.chat) {
    const b = el("div", { class: "msg " + msg.role });
    if (msg.role === "user") b.textContent = msg.content;
    else {
      b.innerHTML = md(msg.content || "Thinking…");
      if (msg.hits) b.append(el("div", { class: "hits" }, msg.hits.map(id => { const c = byId(id); return c ? el("a", { class: "reshit", href: "#/c/" + id, style: "margin:0;padding:8px 10px" },
        el("strong", null, c.code + " " + c.title), el("span", { class: "small" }, c.lead.map(pname).join(", ") + " leads" + (c.sup.length ? ", " + c.sup.map(pname).join(", ") + " support" : "") + ". Target: " + (c.target == null ? "status only" : fmt(c.target) + " " + c.unit) + ". " + (c.page || ""))) : null; })));
    }
    f.append(b);
  }
  box.replaceChildren(f);
  $("#chatSend").textContent = S.busy ? "Stop" : "Ask";
  box.scrollTop = box.scrollHeight;
}
function registerText() {
  const lines = LIST.map(c => { const st = S.progress[c.id];
    return "- {" + c.id + "} [" + c.code + "] " + c.title + (c.tier ? " (" + c.tier + ")" : "") + " | " + compOf(c) + " | Lead: " + c.lead.map(pname).join(", ") +
      (c.sup.length ? " | Supports: " + c.sup.map(pname).join(", ") : "") + " | Target: " + (c.target == null ? "status only" : fmt(c.target) + " " + c.unit) +
      " | Progress: " + (st ? (st.achieved != null ? fmt(st.achieved) + ", " : "") + STATUS[statusOf(c)].label + (st.note ? ", note: " + st.note : "") + ", updated " + when(st.at) : "none logged") +
      (c.details ? " | " + c.details : "") + (c.page ? " | Source: " + c.page : "") + (c.custom ? " | Added by team" : ""); });
  return "You are the UDAAN commitments assistant for a four-partner consortium (YI-Lab lead, NAAMII, HPN, WIA-Nepal) delivering an EU grant in Nepal. " +
    "Answer ONLY from the directory below: the signed full application (Annex A.2) plus commitments and progress the team logged. " +
    "Lead with the direct answer (yes or no, and the number), then the lead partner, supporting partners and source page. " +
    "Every time you mention a specific commitment, put its id in double square brackets right after it, like [[ai-native]], so it becomes a link. Use only ids from the list. " +
    "If the directory says nothing, say the proposal doesn't commit to it and suggest checking the logframe (Annex C), budget (Annex B) or partnership agreements. " +
    "Mention a known inconsistency in one line when it applies. Keep it short; bullets only for lists; no headings.\n\nPARTNERS\n" +
    PKEYS.map(k => "- " + P[k].name + " (" + P[k].full + "): " + P[k].role + " PAT: " + P[k].pat + ". Team: " + P[k].team.concat(P[k].fin).join("; ") + ".").join("\n") +
    "\n\nCOMPONENTS: Pathshala = skills schools and platforms (Outputs 1.1, 1.2); Karyashala = bootcamps, hackathons, incubation (2.1, 2.2); Karmashala = internships, fellowships, Innovation Fellowship (2.3); Nitishala = policy, hubs, schools, podcast, carnival (3.1). 48 months: months 1 to 6 preparatory, three 12-month cycles, final 6 months closure. Governance: PAT (heads, at least twice yearly) and PIT (monthly)." +
    trackingText() + "\n\nCOMMITMENTS (id in braces)\n" + lines.join("\n") + "\n\nKNOWN INCONSISTENCIES\n" + WATCH.map(w => "- " + w.t + ": " + w.p + " (" + w.pages + ")").join("\n");
}
/* ---------- Built-in answer engine (free: no AI service, no API key) ----------
   Understands the common question shapes (yes/no "has X committed to Y", targets, progress,
   who leads, partner and component summaries, status, watch-outs, team roles) and writes a
   short answer straight from the directory and the live Cohort Calendar numbers. */
const STOP = new Set(("a an the and or of for to in on at by with from into about is are was were be been has have had do does did will can could should would " +
  "what which who whom whose how many much any anything there this that these those they them it its our we us you your i me my " +
  "committed commit commitment commitments promise promised deliver delivering give cover tell show list need needs want please " +
  "number numbers target targets total how far progress status so far current currently yet now still ai school tier tiers level levels " +
  "not started start risk risky behind pending ongoing done finished achieved achieve reached under within part about doing work works job role " +
  "lead leads leading responsible owns owner charge get got need required require must").split(" "));
const ALIAS = { YIL: ["yi-lab", "yi lab", "yilab", "youth innovation"], NAAMII: ["naamii", "naami"], HPN: ["hpn", "heifer"], WIA: ["wia", "women in animation"] };
const SYN = { code: "coding", programming: "coding", programmer: "coding", animator: "animation", animate: "animation", intern: "internship",
  hackathon: "hackathon", hack: "hackathon", bootcamp: "bootcamp", incubate: "incubation", incubator: "incubation", mentor: "mentorship",
  app: "application", mobile: "application", school: "school", curriculum: "school", women: "women", gender: "women", female: "women",
  money: "grant", funding: "grant", fund: "grant", fstp: "grant", report: "report", reporting: "report", audit: "audit", sop: "sop", sops: "sop",
  policy: "policy", dialogue: "dialogue", hub: "hub", lab: "hub", podcast: "podcast", carnival: "carnival", municipality: "municipal", municipalities: "municipal",
  official: "officials", cooperative: "cooperative", coop: "cooperative", coops: "cooperative", job: "employment", jobs: "employment" };
const stem = w => { w = SYN[w] || w; if (w.length > 4 && w.endsWith("ies")) w = w.slice(0, -3) + "y"; else if (w.length > 4 && w.endsWith("s") && !w.endsWith("ss")) w = w.slice(0, -1); return SYN[w] || w; };
const bullet = c => "[[" + c.id + "]]";
const joinAnd = a => a.length < 2 ? a.join("") : a.slice(0, -1).join(", ") + " and " + a[a.length - 1];
const whoLine = c => (c.lead.length === 4 ? "All four partners share this" : joinAnd(c.lead.map(pname)) + (c.lead.length > 1 ? " lead" : " leads")) + (c.sup.length ? ", with " + joinAnd(c.sup.map(pname)) + " supporting" : "");

function progressLine(c) {
  const t = tracked(c), st = S.progress[c.id];
  if (t) return "Live from the calendar: **" + fmt(t.trained) + " trained** (" + pctTxt(t.trained, c.target) + "), " + fmt(t.pipeline) + " more in the pipeline.";
  if (st && st.achieved != null) return "Logged: **" + fmt(st.achieved) + "** (" + STATUS[statusOf(c)].label.toLowerCase() + ", " + when(st.at) + ").";
  if (st) return "Status: " + STATUS[statusOf(c)].label.toLowerCase() + " (" + when(st.at) + ").";
  return "No progress logged yet.";
}
function describe(c, withProgress) {
  const who = whoLine(c);
  const tgt = c.target == null ? "No number set" : "**" + fmt(c.target) + "** " + c.unit;
  return "- **" + c.title + "** " + bullet(c) + ": " + tgt + ". " + who + "." + (withProgress ? " " + progressLine(c) : "") + (c.page ? " (" + c.page + ")" : "");
}
function topicMatches(tokens, sharedPenalty) {
  if (!tokens.length) return [];
  const scored = LIST.map(c => {
    const h = HAY.get(c.id), t = c.title.toLowerCase(); let s = 0;
    tokens.forEach(w => { if (h.includes(w)) s += t.includes(w) ? 3 : 1; });
    if (sharedPenalty && c.lead.length === 4) s *= 0.5;   // when asking about one partner, shared targets rank below its own activities
    return { c, s };
  }).filter(x => x.s > 0).sort((a, b) => b.s - a.s);
  if (!scored.length) return [];
  const best = scored[0].s;
  return scored.filter(x => x.s >= Math.max(1, best * 0.6)).slice(0, 8).map(x => x.c);
}
function answerEngine(q) {
  const ql = " " + q.toLowerCase().replace(/[?!.,;:()"]/g, " ").replace(/\s+/g, " ") + " ";
  const partners = PKEYS.filter(k => ALIAS[k].some(a => ql.includes(" " + a + " ") || ql.includes(" " + a + "'")));
  const partnerWords = new Set(partners.flatMap(k => ALIAS[k].join(" ").split(" ")));
  const tiers = ["ai-native", "ai-foundation", "ai-deep"].filter(id => ql.includes(" " + id.slice(3) + " "));
  const comp = COMPS.find(cp => ql.includes(cp.id.toLowerCase()));
  const yesNo = /^\s*(has|have|does|do|did|is|are|will|can|should)\b/.test(ql);
  const askProgress = /\b(progress|how far|achiev|trained|so far|pace|on track|where are we|done so far|completed|reached)/.test(ql);
  const askWho = /\b(who|whose|responsible|owns|owner|in charge)\b/.test(ql);
  const statusWord = /\bat risk|risky\b/.test(ql) ? "at_risk" : /\bnot started|haven't started|pending\b/.test(ql) ? "not_started" : /\bin progress|ongoing\b/.test(ql) ? "in_progress" : /\b(done|finished|achieved)\b/.test(ql) && !tiers.length ? "done" : null;
  const tokens = [...new Set(ql.trim().split(" ").filter(w => w.length > 2 && !STOP.has(w) && !partnerWords.has(w) && !["native", "foundation", "deep"].includes(w)).map(stem))]
    .filter(w => !COMPS.some(cp => cp.id.toLowerCase() === w));
  const out = [];

  // 1. Watch-outs and mismatches
  if (/\b(watch|inconsisten|mismatch|contradict|discrepan|conflict|issue|problem|error|wrong)/.test(ql) && !tiers.length && !partners.length) {
    out.push("The proposal has **" + WATCH.length + " watch-outs** to settle:");
    WATCH.forEach((w, i) => out.push("- **" + w.t + "**" + ((WATCH_REL[i] || [])[0] ? " " + bullet(byId(WATCH_REL[i][0])) : "") + ". " + w.a));
    const live = trackChecks().filter(x => x.lvl === "bad" || x.lvl === "warn");
    if (live.length) { out.push("From the live Cohort Calendar:"); live.forEach(x => out.push("- **" + x.t + "**. " + x.p)); }
    return { content: out.join("\n") };
  }
  // 2. Status lists ("which are at risk / not started")
  if ((statusWord || /\bbehind\b/.test(ql)) && !tokens.length && !tiers.length) {
    const want = statusWord ? [statusWord] : ["at_risk"];
    if (/not started/.test(ql) && /risk/.test(ql)) want.push("not_started");
    const list = LIST.filter(c => want.includes(statusOf(c)) && (!partners.length || c.lead.some(k => partners.includes(k))));
    const behind = /\bbehind|risk\b/.test(ql) ? trackChecks().filter(x => /behind/.test(x.t)) : [];
    if (!list.length && !behind.length) return { content: "Nothing is marked " + want.map(w => STATUS[w].label.toLowerCase()).join(" or ") + (partners.length ? " for " + partners.map(pname).join(" or ") : "") + " right now." };
    if (list.length) {
      out.push("**" + list.length + "** commitment" + (list.length === 1 ? " is " : "s are ") + want.map(w => STATUS[w].label.toLowerCase()).join(" or ") + (partners.length ? " for " + partners.map(pname).join(" or ") : "") + ":");
      list.slice(0, 12).forEach(c => out.push("- " + c.code + " " + c.title + " " + bullet(c) + " (" + c.lead.map(pname).join(", ") + ")"));
      if (list.length > 12) out.push("Plus " + (list.length - 12) + " more. See the " + STATUS[want[0]].label + " list in the directory.");
    }
    behind.forEach(x => out.push("- **" + x.t + "**. " + x.p));
    return { content: out.join("\n") };
  }
  // 3. Team roles ("who is the community manager", "teaching assistants")
  const roleHits = []; (partners.length ? partners : PKEYS).forEach(k => P[k].team.concat(P[k].fin).forEach(r => { const rl = r.toLowerCase(); if (tokens.length && tokens.every(w => rl.includes(w))) roleHits.push([k, r]); }));
  if (roleHits.length && (/\b(roles?|staff|team|position|manager|officer|assistant|coordinator|engineer|mapper|faculty|mentors?|finance|admin|hr|designer|editor|support)\b/.test(ql) || !topicMatches(tokens).length)) {
    out.push("From the team structure (Figure 2, p.20):");
    roleHits.forEach(([k, r]) => out.push("- **" + r + "** at " + pname(k)));
    out.push("The proposal lists roles, not names.");
    return { content: out.join("\n") };
  }
  // 4a. Words the directory has never heard of
  const unknown = tokens.filter(w => w.length > 3 && !LIST.some(c => HAY.get(c.id).includes(w)));
  if (unknown.length && !tiers.length && !comp) {
    out.push("The full application doesn't mention **" + joinAnd(unknown) + "**, so no partner has committed to it there. If it came up later, check the logframe or partnership agreements and add it with Add commitment.");
    const rest = topicMatches(tokens.filter(w => !unknown.includes(w)));
    if (rest.length && rest.length <= 4) { out.push("Closest related commitments:"); rest.forEach(c => out.push(describe(c, false))); }
    return { content: out.join("\n") };
  }
  // 4b. Component summary ("what is under Nitishala?")
  if (comp && !tokens.length && !partners.length && !tiers.length) {
    const list = LIST.filter(c => compOf(c) === comp.id);
    out.push("**" + comp.id + "** covers " + comp.blurb.toLowerCase() + " (Output " + joinAnd(comp.outs) + "). It has **" + list.length + "** commitments:");
    list.forEach(c => out.push(describe(c, askProgress)));
    return { content: out.join("\n") };
  }
  // 4. Which commitments is the question about?
  let cs = tiers.length ? tiers.map(byId) : topicMatches(tokens, partners.length > 0);
  if (comp && !cs.length) cs = LIST.filter(c => compOf(c) === comp.id);
  if (!tiers.length && /\b(ai school|tiers?|levels?)\b/.test(ql) && /\b(ai|native|foundation|deep)\b/.test(ql)) cs = ["ai-native", "ai-foundation", "ai-deep"].map(byId);
  const showProgress = askProgress || cs.some(c => tracked(c));

  // 5. Partner questions
  if (partners.length && !cs.length) {   // "what does HPN do?"
    partners.forEach(k => {
      const led = LIST.filter(c => c.lead.includes(k) && c.g !== "MG" && c.g !== "OC"), sup = LIST.filter(c => !c.lead.includes(k) && c.sup.includes(k));
      out.push("**" + P[k].name + "** (" + P[k].full + "). " + P[k].role);
      out.push("It leads **" + led.length + "** delivery commitments and supports " + sup.length + " more. The main ones:");
      led.filter(c => c.target != null).slice(0, 10).forEach(c => out.push(describe(c, askProgress)));
    });
    return { content: out.join("\n") };
  }
  if (partners.length && cs.length) {
    partners.forEach(k => {
      const led = cs.filter(c => c.lead.includes(k)), sup = cs.filter(c => !c.lead.includes(k) && c.sup.includes(k));
      if (led.length || sup.length) {
        out.push((yesNo ? "**Yes.** " : "") + P[k].name + (led.length ? " leads " + led.length + (sup.length ? " and supports " + sup.length : "") : " supports " + sup.length) + " of these:");
        led.concat(sup).forEach(c => out.push(describe(c, showProgress)));
      } else {
        const owners = [...new Set(cs.flatMap(c => c.lead))].map(pname);
        out.push((yesNo ? "**No.** " : "") + P[k].name + " has no commitment on this in the proposal. " + (owners.length ? "It sits with **" + owners.join(" and ") + "**:" : ""));
        cs.slice(0, 5).forEach(c => out.push(describe(c, showProgress)));
        out.push("If it was agreed separately, add it from the partnership agreement with Add commitment.");
      }
    });
    return { content: out.join("\n") };
  }
  // 6. Commitment questions (targets, progress, who leads)
  if (cs.length) {
    if (askWho && cs.length <= 5) {
      const owners = [...new Set(cs.flatMap(c => c.lead))];
      if (owners.length === 1) out.push("**" + pname(owners[0]) + "** leads " + (cs.length > 1 ? "all of these" : "this") + ":");
      cs.forEach(c => out.push(describe(c, askProgress)));
    }
    else { if (cs.length > 1) out.push("Here's what the proposal commits to:"); cs.forEach(c => out.push(describe(c, showProgress))); }
    const ids = cs.map(c => c.id);
    if (["ai-native", "ai-foundation", "ai-deep"].every(id => ids.includes(id))) {
      out.push("Together that's **22,000** learners across the three tiers. Only Foundation and Deep completions count in the Output 1.1 indicator; Native counts through Shikshya.org enrolment.");
      if (S.track) out.push("Live total so far: **" + fmt(S.track.totals.trained) + " trained** (" + pctTxt(S.track.totals.trained, 22000) + ").");
    }
    WATCH.filter((w, i) => (WATCH_REL[i] || []).some(id => ids.includes(id))).slice(0, 2).forEach(w => out.push("Watch-out: " + w.t + ". " + w.a));
    return { content: out.join("\n") };
  }
  return { content: "I couldn't find that in the directory. Try naming a partner (YI-Lab, NAAMII, HPN, WIA-Nepal), a tier (AI Native, Foundation, Deep), or an activity such as hackathon, internship, podcast or innovation hub. If it isn't in the full application, it may be in the logframe or a partnership agreement, which you can add with Add commitment." };
}
function localAnswer(q) { return answerEngine(q); }
async function send(text) {
  text = (text || "").trim(); if (!text || S.busy) return;
  S.chat.push({ role: "user", content: text });
  if (!CFG.chatProxyUrl) { S.chat.push(Object.assign({ role: "assistant" }, localAnswer(text))); renderChat(); return; }
  const ans = { role: "assistant", content: "" }; S.chat.push(ans);
  S.busy = true; S.ctrl = new AbortController(); renderChat();
  const msgs = S.chat.slice(0, -1).slice(-8).map(x => ({ role: x.role, content: x.content || "(no answer)" }));
  while (msgs.length && msgs[0].role !== "user") msgs.shift();
  msgs[msgs.length - 1] = { role: "user", content: "I'm currently viewing: " + routeLabel(route()) + ".\n\n" + text };
  try {
    const token = S.api ? await S.api.idToken() : null;
    const box = $("#msgs");
    for await (const t of streamChat(CFG.chatProxyUrl, token, registerText(), msgs, S.ctrl.signal)) {
      ans.content = t; const b = box.lastElementChild; if (b) { b.innerHTML = md(t); box.scrollTop = box.scrollHeight; }
    }
    if (!ans.content) ans.content = "No answer came back. Try again.";
  } catch (e) {
    if (S.ctrl && S.ctrl.signal.aborted) ans.content = (ans.content ? ans.content + "\n\n" : "") + "Stopped.";
    else { ans.content = answerEngine(text).content + "\n\n(" + (e.message || "The AI assistant is unavailable.") + " This answer came from the built-in engine.)"; }
  }
  S.busy = false; S.ctrl = null; renderChat();
}
function openChat() { document.body.classList.add("chat-open"); document.body.classList.toggle("dock", innerWidth >= 1100); renderChat(); setTimeout(() => $("#chatIn").focus(), 50); }
function closeChat() { document.body.classList.remove("chat-open", "dock"); }

/* ---------- Sign-in ---------- */
function openSignIn() { $("#siErr").textContent = ""; $("#signin").showModal(); }
$("#siCancel").addEventListener("click", () => $("#signin").close());
$("#signinForm").addEventListener("submit", async e => {
  e.preventDefault();
  try { await S.api.signIn($("#siEmail").value.trim(), $("#siPass").value); $("#siPass").value = ""; $("#signin").close(); }
  catch (err) { $("#siErr").textContent = /invalid|wrong|not-found|credential/.test(err.code || "") ? "That email and password don't match." : "Couldn't sign in. Try again."; }
});
$("#authBtn").addEventListener("click", () => { if (!S.api) return; if (S.user) S.api.signOut(); else openSignIn(); });

/* ---------- Wiring ---------- */
$("#fab").addEventListener("click", openChat);
$("#trackSwitch").addEventListener("click", () => setTrackOn(!S.trackOn));
$("#askTop").addEventListener("click", () => document.body.classList.contains("chat-open") ? closeChat() : openChat());
$("#closeChat").addEventListener("click", closeChat);
$("#clearChat").addEventListener("click", () => { if (S.ctrl) S.ctrl.abort(); S.chat = []; renderChat(); });
$("#chatSend").addEventListener("click", () => { if (S.busy) { if (S.ctrl) S.ctrl.abort(); return; } const t = $("#chatIn"); send(t.value); t.value = ""; });
$("#chatIn").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); if (!S.busy) { send(e.target.value); e.target.value = ""; } } });
$("#msgs").addEventListener("click", e => { if (e.target.closest("a") && innerWidth < 1100) closeChat(); });
$("#menuBtn").addEventListener("click", () => document.body.classList.toggle("nav-open"));
$("#scrim").addEventListener("click", () => document.body.classList.remove("nav-open"));
$("#searchForm").addEventListener("submit", e => { e.preventDefault(); const v = $("#q").value.trim(); if (v) location.hash = "#/search/" + encodeURIComponent(v); });
let searchTimer;
$("#q").addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    const v = $("#q").value.trim(); if (v.length < 2) return;
    history.replaceState(null, "", "#/search/" + encodeURIComponent(v)); renderNav(); renderMain(); $("#q").value = v;
  }, 220);
});
addEventListener("hashchange", () => { S.dirty = false; document.body.classList.remove("nav-open"); renderAll(); scrollTo(0, 0); });
addEventListener("resize", () => { if (document.body.classList.contains("chat-open")) document.body.classList.toggle("dock", innerWidth >= 1100); }, { passive: true });

/* ---------- Start ---------- */
rebuild(); renderAll(); renderChat();
initBackend(CFG, {
  onUser(user) { S.user = user; S.canWrite = !!user; S.accessError = ""; softRender(); },
  onProgress(map) { S.progress = map; softRender(); },
  onCustom(list) { S.custom = list; softRender(); },
  onError(err) {
    if (err && err.code === "permission-denied") { S.canWrite = false; S.accessError = "Your account isn't on the team list yet. Ask the directory admin to add your email."; }
    softRender();
  }
}).then(api => { S.api = api; softRender(); }).catch(() => { S.api = null; softRender(); });

if (COHORT && S.trackOn) connectTracking();
