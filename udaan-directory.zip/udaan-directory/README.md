# UDAAN commitments directory

A searchable directory of what each UDAAN consortium partner (YI-Lab, NAAMII, HPN, WIA-Nepal) committed to the EU, with shared progress tracking and an Ask panel.

Plain HTML, CSS and JavaScript. No framework, no build step, no `npm install`. It runs on GitHub Pages as-is.

```
index.html          page shell
config.js           the only file you edit to go live (Firebase + chat URL)
assets/data.js      commitments from Annex A.2 (edit here to correct or add baseline items)
assets/app.js       directory, search, progress logging, Ask panel
assets/backend.js   Firebase (loaded only if configured) and chat streaming
assets/styles.css   styles, light and dark mode
firestore.rules     database security rules
worker/             optional chat proxy for Claude answers (Cloudflare Worker)
.nojekyll           tells GitHub Pages to serve files untouched
```

## How it works at each level

| What you set up | What the team gets |
|---|---|
| Nothing (just upload) | Full directory, search, watch-outs, live Cohort Calendar numbers, and an Ask panel with a built-in answer engine |
| + Firebase | Sign-in, shared progress logging, history, "Add commitment" |
| + Chat worker (optional, paid API) | Ask panel handles open-ended questions using Claude instead of the built-in engine |
| Cohort Calendar link (on by default) | Live AI Native, Foundation and Deep numbers from the calendar, compared with the EU commitments |

## Running it for free

GitHub Pages (public repository), Firebase on its free Spark plan, and the built-in Ask engine together cost nothing. You don't need a card, an API key or Cloudflare. Do steps 1 and 2 below and skip step 3.

The built-in engine answers the common question shapes directly from the data:

- "Has NAAMII committed to animation?"
- "What numbers do we need for AI Native, Foundation and Deep?"
- "How far are we on AI Foundation?"
- "Who leads the hackathons?"
- "What does HPN have to deliver?"
- "What is under Nitishala?"
- "Which commitments are at risk?"
- "Any inconsistencies?"
- "Who is the finance officer at HPN?"

Each answer links to the commitments it mentions. Step 3 is only needed if you later want open-ended, AI-written answers.

## 1. Put it on GitHub Pages

1. Create a repository, for example `UDAAN-Commitments`.
2. Upload every file and folder from this folder, keeping the structure (including `.nojekyll`).
3. Go to **Settings > Pages**, set Source to **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
4. After a minute the site is live at `https://<your-username>.github.io/UDAAN-Commitments/`.

To test locally first, run `python3 -m http.server` in this folder and open `http://localhost:8000`. Opening `index.html` by double-clicking won't work, because browsers block JavaScript modules from `file://`.

## 2. Turn on shared progress (Firebase)

1. In the [Firebase console](https://console.firebase.google.com), create a project (or reuse one).
2. **Build > Authentication > Get started**, enable **Email/Password**. Under **Users**, add an account for each team member.
3. **Build > Firestore Database > Create database** (production mode).
4. **Firestore > Rules**: paste the contents of `firestore.rules` and Publish.
5. **Firestore > Data**: create a collection named `team`. Add one document per team member. The **document ID is their sign-in email in lower case**, and it can have any field, for example `role: "editor"`. Only people listed here can read or write progress.
6. **Project settings > General > Your apps > Add app > Web**. Copy the config object into `config.js` under `firebase:`.
7. **Authentication > Settings > Authorized domains**: add `<your-username>.github.io`.

The Firebase web config is safe to publish: it only identifies the project. The security rules are what protect the data.

## 3. Optional, paid: Claude answers in the Ask panel

The API key must never go in this repository, so the chat goes through a small Cloudflare Worker that holds the key, checks the person is signed in, and streams the answer back.

1. Get an API key from the [Claude Console](https://console.anthropic.com).
2. Install Wrangler and deploy from the `worker/` folder:
   ```
   cd worker
   npx wrangler login
   npx wrangler secret put ANTHROPIC_API_KEY
   npx wrangler deploy
   ```
3. Before deploying, edit `worker/wrangler.toml`:
   - `FIREBASE_PROJECT`: your Firebase project ID.
   - `ALLOWED_ORIGIN`: `https://<your-username>.github.io`, with no trailing slash and no repo path.
   - `ALLOWED_EMAILS`: optional extra allowlist.
4. Put the worker URL (for example `https://udaan-chat.<you>.workers.dev`) in `config.js` as `chatProxyUrl`.

The worker uses `claude-haiku-5-5` by default, the fastest and cheapest option. The register is sent as a cached system prompt, so follow-up questions cost much less. Change `MODEL` in `wrangler.toml` to `claude-sonnet-5-5` for more careful answers.

## Live link to the Cohort Calendar

**The toggle.** "Connect with Project Tracking System" sits in the top bar, on the overview page and on the Commitments vs tracking page.

- **On:** the directory connects to the calendar's database, pulls every cohort, and compares the numbers with the EU commitments.
- **Off:** it disconnects completely and shows only progress logged by hand.

Each person's choice is remembered in their browser. `defaultOn` in `config.js` sets the starting position for first-time visitors.

**Auto-update, in two ways:**

1. **Data updates in real time.** While the toggle is on, the directory listens to the calendar's database. When anyone adds, completes or edits a cohort, or changes a target in Settings, the numbers here update within seconds, with no page refresh.
2. **Settings follow the calendar's code.** `autoDetectFrom` points at the calendar's `index.html` on GitHub. When the toggle is switched on, the directory reads the Firebase project, programs, collections and master targets from that file. If you add a program or rename a collection in the calendar repo, the directory picks it up on the next connect. The file is cached for 12 hours, and the settings in `config.js` are the fallback.


`config.js > cohortCalendar` connects the directory, read-only, to the Firestore database of the UDAAN Cohort Calendar (project `ai-native-cohort-calendar`). It reads:

- `udaan_events`, `udaan_events_ai_foundation` and `udaan_events_ai_deep`: the cohorts for each tier.
- `udaan_config/project_tracking`: the yearly targets set in the calendar's Settings.

It counts people trained the same way the calendar's Master Dashboard does. Completed institution cohorts count their participants. Completed open cohorts count their seats taken. Completed individuals count one each, unless they are waitlisted.

With this link, the directory:

- shows live numbers on the AI Native, AI Foundation and AI Deep commitments, which replace any manually logged figure;
- adds a **Commitments vs tracking** page with the EU target, the calendar target, trained, pipeline, the year-by-year plan, inclusion figures, provinces and sectors;
- runs **checks**: calendar targets that don't add up to the EU commitment, falling behind the current year's plan, a logged number that disagrees with the calendar, women below 40%, and provinces not yet reached;
- gives the Ask panel the live figures, so "how far are we on AI Foundation?" gets the real number.

If the calendar's Firestore rules are tightened later (recommended, see below), the directory needs read access. The simplest way is to move the directory's own collections (`progress`, `custom`, `team`) into the same Firebase project. Then put that project's config in `config.js > firebase` as well, and one sign-in covers both.

## Updating the commitments

- **Baseline from the signed proposal**: edit `assets/data.js`. Each commitment has an `id` (never change it once progress is logged, because progress is stored under that id), the lead and supporting partners, the target, the unit, details and the source page.
- **Commitments from other documents** (logframe, budget, partnership agreements): signed-in team members use **Add commitment** in the app. These are stored in Firestore.

## Privacy note

On a public repository, anyone can read `assets/data.js`, which holds commitments from the application. Progress, notes and added commitments live in Firestore and are visible only to people in the `team` collection. If the application text itself should stay private, keep the repo private. Publishing Pages from a private repo needs a paid GitHub plan.

## Security note for the Cohort Calendar

The calendar keeps its admin usernames and passwords inside `index.html`. In a public repository, anyone can read them. Its database also has to be readable without signing in for the calendar to work, which includes participant emails. Move admin login to Firebase Authentication and lock the Firestore rules to signed-in users, then change those passwords.

## Why it's fast

- There are no frameworks, and the whole site is about 90 KB before fonts.
- Firebase is only downloaded when it's configured, and only after the page has drawn.
- The calendar comparison is recalculated only when calendar data changes, never on every click.
- There is one live listener per collection, and bursts of updates are merged into a single repaint.
- The search index is built once per data change, and typing in search is debounced.
- Chat answers stream in as they're written, and the large context is cached on Anthropic's side.
