/**
 * UDAAN chat proxy (Cloudflare Worker).
 * Keeps the Anthropic API key off GitHub, only answers signed-in team members,
 * and streams Claude's reply back to the directory.
 *
 * Secrets / variables (set with wrangler or the Cloudflare dashboard):
 *   ANTHROPIC_API_KEY  secret   your Anthropic API key
 *   FIREBASE_PROJECT   var      Firebase project ID, e.g. udaan-directory
 *   ALLOWED_ORIGIN     var      your Pages origin, e.g. https://your-name.github.io
 *   ALLOWED_EMAILS     var      optional comma-separated allowlist; empty = any signed-in user of the project
 *   MODEL              var      optional, defaults to claude-haiku-5-5
 */
const JWKS_URL = "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com";
let jwksCache = { keys: null, until: 0 };

export default {
  async fetch(req, env) {
    const origin = req.headers.get("Origin") || "";
    const cors = {
      "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Vary": "Origin"
    };
    const fail = (status, error) => new Response(JSON.stringify({ error }), { status, headers: { ...cors, "Content-Type": "application/json" } });

    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (req.method !== "POST") return fail(405, "Use POST.");
    if (env.ALLOWED_ORIGIN && origin !== env.ALLOWED_ORIGIN) return fail(403, "This site isn't allowed to use the assistant.");

    // 1. Only signed-in team members.
    let user;
    try { user = await verifyFirebaseToken((req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, ""), env.FIREBASE_PROJECT); }
    catch (e) { return fail(401, "Sign in to use the assistant."); }
    const allow = (env.ALLOWED_EMAILS || "").split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
    if (allow.length && !allow.includes(String(user.email || "").toLowerCase())) return fail(403, "Your account isn't allowed to use the assistant.");

    // 2. Validate and cap the request so nobody can run up the bill.
    let body;
    try { body = await req.json(); } catch (e) { return fail(400, "Bad request."); }
    const system = typeof body.system === "string" ? body.system.slice(0, 80000) : "";
    const messages = Array.isArray(body.messages) ? body.messages.slice(-10)
      .filter(m => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .map(m => ({ role: m.role, content: m.content.slice(0, 4000) })) : [];
    if (!messages.length || messages[messages.length - 1].role !== "user") return fail(400, "Ask a question.");

    // 3. Call Claude. The large register goes in a cached system block, so repeat questions are cheap.
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: env.MODEL || "claude-haiku-5-5",
        max_tokens: 1024,
        stream: true,
        system: [{ type: "text", text: system, cache_control: { type: "ephemeral" } }],
        messages
      })
    });
    if (!upstream.ok || !upstream.body) {
      const status = upstream.status === 429 ? 429 : 502;
      return fail(status, status === 429 ? "Too many questions right now. Wait a minute and try again." : "The assistant is unavailable right now.");
    }
    return new Response(upstream.body, { headers: { ...cors, "Content-Type": "text/event-stream", "Cache-Control": "no-store" } });
  }
};

/* ---- Firebase ID token check (RS256, Google's public keys) ---- */
function b64urlBytes(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "=";
  return Uint8Array.from(atob(s), c => c.charCodeAt(0));
}
const b64urlJson = s => JSON.parse(new TextDecoder().decode(b64urlBytes(s)));

async function getKeys() {
  if (jwksCache.keys && Date.now() < jwksCache.until) return jwksCache.keys;
  const res = await fetch(JWKS_URL);
  const maxAge = Number((/max-age=(\d+)/.exec(res.headers.get("Cache-Control") || "") || [])[1] || 3600);
  jwksCache = { keys: (await res.json()).keys, until: Date.now() + maxAge * 1000 };
  return jwksCache.keys;
}

async function verifyFirebaseToken(token, projectId) {
  const parts = token.split(".");
  if (parts.length !== 3 || !projectId) throw new Error("bad token");
  const [h, p, s] = parts, header = b64urlJson(h), payload = b64urlJson(p), now = Math.floor(Date.now() / 1000);
  if (header.alg !== "RS256") throw new Error("alg");
  if (payload.aud !== projectId || payload.iss !== "https://securetoken.google.com/" + projectId) throw new Error("aud/iss");
  if (!payload.sub || payload.exp <= now || payload.iat > now + 300) throw new Error("time");
  const jwk = (await getKeys()).find(k => k.kid === header.kid);
  if (!jwk) throw new Error("kid");
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  const ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, b64urlBytes(s), new TextEncoder().encode(h + "." + p));
  if (!ok) throw new Error("signature");
  return payload;
}
